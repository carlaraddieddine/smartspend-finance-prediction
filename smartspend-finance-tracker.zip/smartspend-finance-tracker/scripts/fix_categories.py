import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import create_app, db
from app.models import Transaction, Budget

app = create_app()

with app.app_context():
    print("🔧 Fixing transaction categories...")

    tx_rows = Transaction.query.filter_by(category="Transport").all()
    print(f"Found {len(tx_rows)} transactions to update")

    for tx in tx_rows:
        tx.category = "Transportation"

    print("🔧 Fixing budget categories...")

    budget_rows = Budget.query.filter_by(category="Transport").all()
    print(f"Found {len(budget_rows)} budgets to update")

    for b in budget_rows:
        b.category = "Transportation"

    db.session.commit()

    print("✅ All categories updated successfully!")