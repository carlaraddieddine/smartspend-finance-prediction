import os
import sys
import csv
from datetime import datetime, date

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import create_app, db
from app.models import Transaction, User

app = create_app()

AMOUNT_SCALE = 0.05
MAX_EXPENSE_ROWS = 120
TARGET_YEAR = date.today().year
MONTHLY_INCOME = 1500.00


def normalize_category(category):
    mapping = {
        "food & drink": "Food",
        "travel": "Transportation",
        "utilities": "Bills",
        "rent": "Bills",
        "shopping": "Shopping",
        "entertainment": "Entertainment",
        "other": "Other",
        "salary": "Salary",
        "investment": "Other",
        "health & fitness": "Health",
    }
    return mapping.get(category.strip().lower(), category.strip().title())


def normalize_amount(amount):
    return round(float(amount) * AMOUNT_SCALE, 2)


def normalize_date(date_str):
    original = datetime.strptime(date_str, "%Y-%m-%d").date()
    today = date.today()
    candidate = original.replace(year=today.year)
    if candidate > today:
        candidate = candidate.replace(year=today.year - 1)

    return candidate


def import_data():
    with app.app_context():
        user = User.query.first()

        if not user:
            print("No user found. Please register a user first.")
            return

        file_path = os.path.join("data", "raw", "Personal_Finance_Dataset.csv")

        if not os.path.exists(file_path):
            print(f"Dataset file not found: {file_path}")
            return

        count = 0
        expense_months = set()

        with open(file_path, newline="", encoding="utf-8") as csvfile:
            reader = csv.DictReader(csvfile)

            for row in reader:
                if count >= MAX_EXPENSE_ROWS:
                    break

                # only import expense rows from Kaggle
                if row["Type"].strip().lower() != "expense":
                    continue

                try:
                    tx_date = normalize_date(row["Date"])

                    tx = Transaction(
                        user_id=user.id,
                        amount=normalize_amount(row["Amount"]),
                        category=normalize_category(row["Category"]),
                        type="expense",
                        source="dataset",
                        date=tx_date,
                    )
                    db.session.add(tx)
                    count += 1
                    expense_months.add((tx_date.year, tx_date.month))

                except Exception as e:
                    print("Error processing row:", row)
                    print(e)

        # add one salary transaction per month present in imported expense data
        for year, month in sorted(expense_months):
            salary_date = date(year, month, 1)
            salary_tx = Transaction(
                user_id=user.id,
                amount=MONTHLY_INCOME,
                category="Salary",
                type="income",
                source="dataset",
                date=salary_date,
            )
            db.session.add(salary_tx)

        db.session.commit()
        print(f"Dataset imported successfully! {count} expense rows added.")
        print(f"{len(expense_months)} monthly salary transactions added.")


if __name__ == "__main__":
    import_data()