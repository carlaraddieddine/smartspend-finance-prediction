import os
import sys
import joblib
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sklearn.linear_model import LinearRegression
from app import create_app
from app.models import Transaction

app = create_app()


def train_model():
    with app.app_context():
        transactions = Transaction.query.filter_by(type="expense").all()

        rows = []
        for tx in transactions:
            rows.append(
                {
                    "date": tx.date,
                    "amount": tx.amount,
                    "category": tx.category,
                    "source": tx.source,
                }
            )

        df = pd.DataFrame(rows)

        if df.empty:
            print("No expense transactions found.")
            return

        df["date"] = pd.to_datetime(df["date"])
        df["year"] = df["date"].dt.year
        df["month"] = df["date"].dt.month
        df["day"] = df["date"].dt.day

        monthly = (
            df.groupby(["year", "month"])
            .agg(
                total_spending=("amount", "sum"),
                avg_daily_spending=("amount", "mean"),
                transaction_count=("amount", "count"),
            )
            .reset_index()
            .sort_values(["year", "month"])
        )

        if len(monthly) < 2:
            print("Not enough monthly data to train the model.")
            print(monthly)
            return

        monthly["prev_month_spending"] = monthly["total_spending"].shift(1)
        monthly = monthly.dropna()

        if monthly.empty:
            print("Not enough processed rows after feature engineering.")
            return

        X = monthly[["avg_daily_spending", "transaction_count", "prev_month_spending"]]
        y = monthly["total_spending"]

        model = LinearRegression()
        model.fit(X, y)

        os.makedirs("app/ml", exist_ok=True)
        joblib.dump(model, "app/ml/model.pkl")

        print("Model trained successfully!")
        print("Saved to: app/ml/model.pkl")
        print("\nTraining data used:")
        print(monthly)


if __name__ == "__main__":
    train_model()