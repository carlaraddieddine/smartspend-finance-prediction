import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import create_app, db
from app.models import Transaction

app = create_app()


def clear_dataset_transactions():
    with app.app_context():
        rows = Transaction.query.filter_by(source="dataset").all()
        print(f"Found {len(rows)} dataset transactions to delete.")

        for tx in rows:
            db.session.delete(tx)

        db.session.commit()
        print("Old dataset transactions deleted successfully.")


if __name__ == "__main__":
    clear_dataset_transactions()