import json
import os
from openai import OpenAI

ADVISOR_RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "summary": {"type": "string"},
        "observations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "message": {"type": "string"},
                    "importance": {
                        "type": "string",
                        "enum": ["low", "medium", "high"]
                    }
                },
                "required": ["title", "message", "importance"],
                "additionalProperties": False
            }
        },
        "risks": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "message": {"type": "string"},
                    "severity": {
                        "type": "string",
                        "enum": ["warning", "danger"]
                    }
                },
                "required": ["title", "message", "severity"],
                "additionalProperties": False
            }
        },
        "recommendations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "action": {"type": "string"},
                    "priority": {
                        "type": "string",
                        "enum": ["medium", "high"]
                    }
                },
                "required": ["title", "action", "priority"],
                "additionalProperties": False
            }
        }
    },
    "required": ["summary", "observations", "risks", "recommendations"],
    "additionalProperties": False
}


def generate_ai_advice(summary_data, rule_data, prediction_data=None):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None

    client = OpenAI(api_key=api_key)

    system_prompt = """
You are Smart Advisor, a personal finance insight assistant inside a budgeting web app.

Use ONLY the provided structured data.
Do not invent numbers, trends, categories, budgets, or financial facts.
Do not provide legal, tax, debt, or investment advice.
Give practical budgeting guidance only.
Keep insights concise, actionable, and non-repetitive.
Prioritize the biggest financial risks first.
Use the prediction summary when available to explain future overspending risk.
Return JSON only that matches the required schema.
""".strip()

    prediction_section = ""
    if prediction_data:
        prediction_section = f"""

Prediction summary:
{json.dumps(prediction_data, indent=2)}
""".rstrip()

    user_prompt = f"""
Analyze this user's personal finance summary.

Financial summary:
{json.dumps(summary_data, indent=2)}

Rule-based insights:
{json.dumps(rule_data, indent=2)}
{prediction_section}
""".strip()

    response = client.responses.create(
        model="gpt-4o-mini",
        input=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.2,
        max_output_tokens=700,
        text={
            "format": {
                "type": "json_schema",
                "name": "smart_advisor_response",
                "strict": True,
                "schema": ADVISOR_RESPONSE_SCHEMA
            }
        }
    )

    return json.loads(response.output_text)