from datetime import datetime

from app import db
from app.models import SavingsGoal, SavingsGoalContribution


class SavingsGoalService:
    @staticmethod
    def recalculate_goal(goal):
        total_saved = db.session.query(
            db.func.coalesce(db.func.sum(SavingsGoalContribution.amount), 0.0)
        ).filter_by(goal_id=goal.id).scalar()

        goal.current_amount = float(total_saved or 0.0)
        goal.updated_at = datetime.utcnow()
        return goal

    @staticmethod
    def build_goal_payload(goal):
        current_amount = float(goal.current_amount or 0.0)
        target_amount = float(goal.target_amount or 0.0)
        progress_percent = 0

        if target_amount > 0:
            progress_percent = (current_amount / target_amount) * 100

        progress_capped = min(progress_percent, 100)
        remaining_amount = max(target_amount - current_amount, 0)
        status = SavingsGoalService.get_status(goal, progress_percent)
        deadline_text = SavingsGoalService.get_deadline_text(goal, status)

        contributions = goal.contributions or []
        latest_contribution = contributions[0] if contributions else None

        return {
            "id": goal.id,
            "name": goal.name,
            "description": goal.description,
            "target_amount": target_amount,
            "current_amount": current_amount,
            "remaining_amount": remaining_amount,
            "progress_percent": progress_percent,
            "progress_capped": progress_capped,
            "status": status,
            "deadline": goal.deadline,
            "deadline_text": deadline_text,
            "contribution_count": len(contributions),
            "latest_contribution": latest_contribution,
            "created_at": goal.created_at,
        }

    @staticmethod
    def get_status(goal, progress_percent=None):
        if progress_percent is None:
            target_amount = float(goal.target_amount or 0.0)
            current_amount = float(goal.current_amount or 0.0)
            progress_percent = (current_amount / target_amount * 100) if target_amount > 0 else 0

        if progress_percent >= 100:
            return "completed"

        if not goal.deadline:
            return "on_track"

        today = datetime.utcnow().date()
        if goal.deadline < today:
            return "behind"

        total_days = max((goal.deadline - goal.created_at.date()).days, 1)
        elapsed_days = min(max((today - goal.created_at.date()).days, 0), total_days)
        expected_progress = (elapsed_days / total_days) * 100

        if progress_percent + 5 < expected_progress:
            return "behind"

        return "on_track"

    @staticmethod
    def get_deadline_text(goal, status):
        if not goal.deadline:
            return "No target date"

        today = datetime.utcnow().date()
        days_left = (goal.deadline - today).days

        if status == "completed":
            return "Completed"
        if days_left < 0:
            return "Past deadline"
        if days_left == 0:
            return "Due today"
        if days_left == 1:
            return "1 day left"
        return f"{days_left} days left"

    @staticmethod
    def refresh_user_goals(user_id):
        goals = (
            SavingsGoal.query
            .filter_by(user_id=user_id)
            .order_by(SavingsGoal.created_at.desc())
            .all()
        )

        payload = []
        for goal in goals:
            SavingsGoalService.recalculate_goal(goal)
            payload.append(SavingsGoalService.build_goal_payload(goal))

        db.session.commit()
        return payload

    @staticmethod
    def get_summary(goal_rows):
        total_goals = len(goal_rows)
        completed_goals = sum(1 for goal in goal_rows if goal["status"] == "completed")
        active_goals = sum(1 for goal in goal_rows if goal["status"] != "completed")
        total_saved = sum(goal["current_amount"] for goal in goal_rows)

        nearest_deadline = None
        active_with_deadline = [
            goal for goal in goal_rows
            if goal["status"] != "completed" and goal["deadline"]
        ]
        if active_with_deadline:
            nearest_deadline = min(active_with_deadline, key=lambda goal: goal["deadline"])

        return {
            "total_goals": total_goals,
            "completed_goals": completed_goals,
            "active_goals": active_goals,
            "total_saved": total_saved,
            "nearest_deadline": nearest_deadline,
        }