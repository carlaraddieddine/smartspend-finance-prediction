import os
import joblib
import pandas as pd
from sqlalchemy import extract

from app.models import Transaction


MODEL_PATH = os.path.join("app", "ml", "model.pkl")


def load_model():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}")
    return joblib.load(MODEL_PATH)


def calculate_risk(predicted_spending, total_budget):
    if total_budget is None or total_budget <= 0:
        return "Unknown"

    ratio = predicted_spending / total_budget

    if ratio < 0.8:
        return "Low"
    elif ratio <= 1.0:
        return "Medium"
    return "High"


def get_user_monthly_expense_features(user_id, year, month):
    transactions = (
        Transaction.query.filter_by(user_id=user_id, type="expense")
        .filter(extract("year", Transaction.date) == year)
        .filter(extract("month", Transaction.date) == month)
        .all()
    )

    if not transactions:
        return None

    rows = []
    for tx in transactions:
        rows.append(
            {
                "date": tx.date,
                "amount": tx.amount,
                "category": tx.category,
                "source": tx.source,
            }
        )

    df = pd.DataFrame(rows)
    df["date"] = pd.to_datetime(df["date"])

    avg_daily_spending = df["amount"].mean()
    transaction_count = df["amount"].count()

    prev_month = month - 1
    prev_year = year

    if prev_month == 0:
        prev_month = 12
        prev_year -= 1

    prev_transactions = (
        Transaction.query.filter_by(user_id=user_id, type="expense")
        .filter(extract("year", Transaction.date) == prev_year)
        .filter(extract("month", Transaction.date) == prev_month)
        .all()
    )

    prev_month_spending = sum(tx.amount for tx in prev_transactions) if prev_transactions else 0.0

    return {
        "avg_daily_spending": avg_daily_spending,
        "transaction_count": transaction_count,
        "prev_month_spending": prev_month_spending,
        "current_total_spending": df["amount"].sum(),
    }


def predict_month_end_spending(user_id, year, month, total_budget):
    model = load_model()
    features = get_user_monthly_expense_features(user_id, year, month)

    if not features:
        return None

    X = pd.DataFrame(
        [
            {
                "avg_daily_spending": features["avg_daily_spending"],
                "transaction_count": features["transaction_count"],
                "prev_month_spending": features["prev_month_spending"],
            }
        ]
    )

    predicted_spending = float(model.predict(X)[0])
    risk_level = calculate_risk(predicted_spending, total_budget)

    return {
        "predicted_month_end_spending": round(predicted_spending, 2),
        "current_total_spending": round(float(features["current_total_spending"]), 2),
        "transaction_count": int(features["transaction_count"]),
        "prev_month_spending": round(features["prev_month_spending"], 2),
        "total_budget": round(float(total_budget), 2) if total_budget else 0.0,
        "risk_level": risk_level,
    }
def get_total_budget_for_user(user_id):
    from app.models import Budget

    budgets = Budget.query.filter_by(user_id=user_id).all()
    if not budgets:
        return 0.0

    return float(sum(b.limit_amount for b in budgets))