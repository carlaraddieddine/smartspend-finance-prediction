from collections import defaultdict
from datetime import datetime, timedelta

from app import db
from app.models import Transaction, Budget, AdvisorSnapshot
from app.services.ai_client import generate_ai_advice
from app.services.prediction_service import (
    predict_month_end_spending,
    get_total_budget_for_user,
)


class SmartAdvisorService:
    CACHE_HOURS = 8

    @staticmethod
    def _get_period_dates(period="monthly"):
        today = datetime.utcnow().date()

        if period == "weekly":
            start_date = today - timedelta(days=6)
            prev_start = start_date - timedelta(days=7)
            prev_end = start_date - timedelta(days=1)
        else:
            start_date = today.replace(day=1)
            prev_end = start_date - timedelta(days=1)
            prev_start = prev_end.replace(day=1)

        return start_date, today, prev_start, prev_end

    @staticmethod
    def _get_transactions(user_id, start_date, end_date):
        return (
            Transaction.query
            .filter_by(user_id=user_id)
            .filter(Transaction.date >= start_date, Transaction.date <= end_date)
            .order_by(Transaction.date.asc())
            .all()
        )

    @staticmethod
    def build_summary(user_id, period="monthly"):
        start_date, end_date, prev_start, prev_end = SmartAdvisorService._get_period_dates(period)

        current_txs = SmartAdvisorService._get_transactions(user_id, start_date, end_date)
        previous_txs = SmartAdvisorService._get_transactions(user_id, prev_start, prev_end)

        income_total = sum(tx.amount for tx in current_txs if tx.type == "income")
        expense_total = sum(tx.amount for tx in current_txs if tx.type == "expense")
        net_balance = income_total - expense_total
        savings_rate = round((net_balance / income_total) * 100, 2) if income_total > 0 else 0.0

        prev_expense_total = sum(tx.amount for tx in previous_txs if tx.type == "expense")
        spending_change_pct = 0.0
        if prev_expense_total > 0:
            spending_change_pct = round(((expense_total - prev_expense_total) / prev_expense_total) * 100, 2)

        category_totals = defaultdict(float)
        for tx in current_txs:
            if tx.type == "expense":
                category_totals[tx.category] += tx.amount

        sorted_categories = sorted(category_totals.items(), key=lambda x: x[1], reverse=True)
        top_categories = []
        for category, amount in sorted_categories[:6]:
            share = round((amount / expense_total) * 100, 2) if expense_total > 0 else 0.0
            top_categories.append({
                "category": category,
                "amount": round(amount, 2),
                "share": share
            })

        budget_rows = Budget.query.filter_by(user_id=user_id).all()
        budget_statuses = []
        for budget in budget_rows:
            spent = float(category_totals.get(budget.category, 0.0))
            usage_pct = round((spent / budget.limit_amount) * 100, 2) if budget.limit_amount > 0 else 0.0

            if usage_pct >= 100:
                status = "danger"
            elif usage_pct >= 80:
                status = "warning"
            else:
                status = "ok"

            budget_statuses.append({
                "category": budget.category,
                "limit": round(float(budget.limit_amount), 2),
                "spent": round(spent, 2),
                "usage_pct": usage_pct,
                "status": status
            })

        return {
            "period": period,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "income_total": round(income_total, 2),
            "expense_total": round(expense_total, 2),
            "net_balance": round(net_balance, 2),
            "savings_rate": savings_rate,
            "expense_transaction_count": len([tx for tx in current_txs if tx.type == "expense"]),
            "spending_change_pct": spending_change_pct,
            "top_categories": top_categories,
            "budget_statuses": budget_statuses
        }

    @staticmethod
    def build_rule_insights(summary, prediction=None):
        observations = []
        risks = []
        recommendations = []

        income_total = summary["income_total"]
        net_balance = summary["net_balance"]
        savings_rate = summary["savings_rate"]
        spending_change_pct = summary["spending_change_pct"]
        top_categories = summary["top_categories"]
        budget_statuses = summary["budget_statuses"]

        def recommendation_exists(title):
            return any(r["title"] == title for r in recommendations)

        # Top category insight
        if top_categories:
            top = top_categories[0]
            observations.append({
                "title": "Top spending category",
                "message": f"{top['category']} is your largest expense at ${top['amount']:.2f}, representing {top['share']:.1f}% of total spending.",
                "importance": "high" if top["share"] >= 30 else "medium"
            })

            if top["share"] >= 35:
                risks.append({
                    "title": "Spending concentration risk",
                    "message": f"A large share of your spending is concentrated in {top['category']}, which reduces flexibility in your budget.",
                    "severity": "warning"
                })
                if not recommendation_exists(f"Reduce {top['category']} gradually"):
                    recommendations.append({
                        "title": f"Reduce {top['category']} gradually",
                        "action": f"Start by reducing spending in {top['category']} by a small percentage next week to lower overall pressure.",
                        "priority": "high"
                    })

        # Cash flow
        if net_balance < 0:
            risks.append({
                "title": "Negative cash flow",
                "message": f"You spent ${abs(net_balance):.2f} more than you earned in this period.",
                "severity": "danger"
            })
            if not recommendation_exists("Stabilize monthly balance"):
                recommendations.append({
                    "title": "Stabilize monthly balance",
                    "action": "Reduce non-essential spending immediately and prioritize essential categories until expenses fall below income.",
                    "priority": "high"
                })
        else:
            observations.append({
                "title": "Positive balance",
                "message": f"You currently have a positive balance of ${net_balance:.2f} for this period.",
                "importance": "medium"
            })

        # Savings rate
        if income_total > 0:
            if savings_rate < 10:
                risks.append({
                    "title": "Low savings rate",
                    "message": f"Your savings rate is {savings_rate:.1f}%, which leaves little room for unexpected expenses.",
                    "severity": "warning"
                })
                if not recommendation_exists("Increase savings buffer"):
                    recommendations.append({
                        "title": "Increase savings buffer",
                        "action": "Aim to reserve a fixed portion of each income transaction before spending on flexible categories.",
                        "priority": "medium"
                    })
            elif 20 <= savings_rate <= 50:
                observations.append({
                    "title": "Healthy savings behavior",
                    "message": f"Your savings rate is {savings_rate:.1f}%, which indicates strong financial control.",
                    "importance": "medium"
                })
            elif savings_rate > 50:
                observations.append({
                    "title": "Very high savings rate",
                    "message": "Your savings rate is unusually high, which may indicate under-spending this period or missing expenses.",
                    "importance": "low"
                })

        # Spending trend
        if spending_change_pct >= 20:
            risks.append({
                "title": "Spending increased sharply",
                "message": f"Your spending increased by {spending_change_pct:.1f}% compared with the previous period.",
                "severity": "warning"
            })
            if not recommendation_exists("Review recent spending growth"):
                recommendations.append({
                    "title": "Review recent spending growth",
                    "action": "Compare this period with the previous one and reduce the categories that increased the most.",
                    "priority": "high"
                })
        elif spending_change_pct <= -10:
            observations.append({
                "title": "Spending improved",
                "message": f"Your spending decreased by {abs(spending_change_pct):.1f}% compared with the previous period.",
                "importance": "medium"
            })

        if abs(spending_change_pct) >= 15:
            observations.append({
                "title": "Significant spending change",
                "message": f"Your spending changed by {spending_change_pct:.1f}% compared to the previous period, which may indicate a behavior shift.",
                "importance": "high" if abs(spending_change_pct) >= 25 else "medium"
            })

        # Budget pressure
        for budget in budget_statuses:
            if budget["status"] == "danger":
                risks.append({
                    "title": f"{budget['category']} budget exceeded",
                    "message": f"You spent ${budget['spent']:.2f} out of ${budget['limit']:.2f} ({budget['usage_pct']:.1f}%).",
                    "severity": "danger"
                })
                title = f"Control {budget['category']} spending"
                if not recommendation_exists(title):
                    recommendations.append({
                        "title": title,
                        "action": f"Pause or reduce spending in {budget['category']} until it returns closer to the planned limit.",
                        "priority": "high"
                    })
            elif budget["status"] == "warning":
                risks.append({
                    "title": f"{budget['category']} budget under pressure",
                    "message": f"You already used {budget['usage_pct']:.1f}% of your {budget['category']} budget.",
                    "severity": "warning"
                })

        # Prediction-aware advice
        if prediction:
            risk_level = prediction.get("risk_level")
            predicted_spending = float(prediction.get("predicted_month_end_spending", 0))
            total_budget = float(prediction.get("total_budget", 0))

            if risk_level == "High":
                risks.append({
                    "title": "High predicted overspending risk",
                    "message": f"Your predicted end-of-month spending is ${predicted_spending:.2f}, which is above your total budget of ${total_budget:.2f}.",
                    "severity": "danger"
                })
                if not recommendation_exists("Act before month-end"):
                    recommendations.append({
                        "title": "Act before month-end",
                        "action": "Reduce flexible spending now, especially in your top expense categories, to avoid exceeding your budget.",
                        "priority": "high"
                    })
            elif risk_level == "Medium":
                risks.append({
                    "title": "Moderate budget pressure",
                    "message": f"Your predicted month-end spending is ${predicted_spending:.2f}, which is close to your total budget of ${total_budget:.2f}.",
                    "severity": "warning"
                })
                if not recommendation_exists("Stay below budget threshold"):
                    recommendations.append({
                        "title": "Stay below budget threshold",
                        "action": "Keep discretionary spending low for the rest of the month and monitor your top categories closely.",
                        "priority": "medium"
                    })
            elif risk_level == "Low":
                observations.append({
                    "title": "Predicted spending is under control",
                    "message": "Your predicted month-end spending remains comfortably below your total budget.",
                    "importance": "medium"
                })
            elif risk_level == "Unknown":
                observations.append({
                    "title": "Prediction available but budget incomplete",
                    "message": "The system predicted your month-end spending, but a total budget is needed to evaluate overspending risk accurately.",
                    "importance": "medium"
                })

        # Fallback recommendation
        if not recommendations and top_categories:
            top = top_categories[0]
            recommendations.append({
                "title": "Focus on the biggest category",
                "action": f"Start with {top['category']} because changes there will have the biggest impact on your overall spending.",
                "priority": "medium"
            })

        return {
            "observations": observations[:4],
            "risks": risks[:4],
            "recommendations": recommendations[:4]
        }

    @staticmethod
    def calculate_health(summary, prediction=None):
        score = 100

        if summary["net_balance"] < 0:
            score -= 40

        if summary["savings_rate"] < 10:
            score -= 20

        if summary["spending_change_pct"] > 20:
            score -= 15

        over_budget_count = len([b for b in summary["budget_statuses"] if b["status"] == "danger"])
        near_limit_count = len([b for b in summary["budget_statuses"] if b["status"] == "warning"])

        score -= over_budget_count * 10
        score -= near_limit_count * 5

        if prediction:
            risk_level = prediction.get("risk_level")
            if risk_level == "High":
                score -= 20
            elif risk_level == "Medium":
                score -= 10

        return max(score, 0)

    @staticmethod
    def _get_snapshot(user_id, period):
        return (
            AdvisorSnapshot.query
            .filter_by(user_id=user_id, period=period)
            .order_by(AdvisorSnapshot.created_at.desc())
            .first()
        )

    @staticmethod
    def get_advisor_payload(user_id, period="monthly", force_refresh_ai=False):
        summary = SmartAdvisorService.build_summary(user_id, period)

        today = datetime.utcnow()
        year = today.year
        month = today.month

        total_budget = get_total_budget_for_user(user_id)
        prediction_result = predict_month_end_spending(
            user_id=user_id,
            year=year,
            month=month,
            total_budget=total_budget,
        )

        rule_data = SmartAdvisorService.build_rule_insights(summary, prediction_result)

        snapshot = SmartAdvisorService._get_snapshot(user_id, period)
        use_cached_ai = snapshot and snapshot.is_valid and not force_refresh_ai

        ai_data = snapshot.get_ai_data() if use_cached_ai else None

        if ai_data is None:
            try:
                ai_data = generate_ai_advice(summary, rule_data, prediction_result)
            except Exception as e:
                print("AI generation error:", e)
                ai_data = None

            expires_at = datetime.utcnow() + timedelta(hours=SmartAdvisorService.CACHE_HOURS)

            if snapshot is None:
                snapshot = AdvisorSnapshot(
                    user_id=user_id,
                    period=period,
                    expires_at=expires_at
                )
                db.session.add(snapshot)

            snapshot.set_summary(summary)
            snapshot.set_rule_data(rule_data)
            snapshot.set_ai_data(ai_data or {})
            snapshot.created_at = datetime.utcnow()
            snapshot.expires_at = expires_at
            db.session.commit()

        final_ai = ai_data or {}

        if not final_ai.get("recommendations"):
            final_ai["recommendations"] = rule_data["recommendations"]
        if not final_ai.get("risks"):
            final_ai["risks"] = rule_data["risks"]
        if not final_ai.get("observations"):
            final_ai["observations"] = rule_data["observations"]
        if not final_ai.get("summary"):
            top_cat = summary["top_categories"][0]["category"] if summary["top_categories"] else "your main category"
            if prediction_result and prediction_result.get("risk_level") in ("Medium", "High"):
                final_ai["summary"] = (
                    f"You are spending most heavily in {top_cat}. "
                    f"Predicted month-end spending is ${prediction_result['predicted_month_end_spending']:.2f}, "
                    f"and the current risk level is {prediction_result['risk_level']}."
                )
            else:
                final_ai["summary"] = (
                    f"Your recent financial activity is being tracked successfully. "
                    f"The biggest spending pressure currently comes from {top_cat}."
                )

        top_recommendations = final_ai.get("recommendations") or rule_data["recommendations"]
        top_priority = top_recommendations[0] if top_recommendations else None
        health_score = SmartAdvisorService.calculate_health(summary, prediction_result)

        if health_score > 75:
            health_label = "Healthy"
        elif health_score > 50:
            health_label = "Stable"
        else:
            health_label = "Needs Attention"

        return {
            "summary": summary,
            "rules": rule_data,
            "ai": final_ai,
            "prediction": prediction_result,
            "top_priority": top_priority,
            "health_score": health_score,
            "health_label": health_label,
            "last_updated": snapshot.created_at if snapshot else datetime.utcnow()
        }