from datetime import datetime
import json

from flask_login import UserMixin
from app import db, login_manager

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password = db.Column(db.String(255), nullable=False)
    preferred_currency = db.Column(db.String(10), nullable=False, default="USD")
    notifications_enabled = db.Column(db.Boolean, nullable=False, default=True)

    transactions = db.relationship(
        "Transaction",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan"
    )
    budgets = db.relationship(
        "Budget",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan"
    )
    categories = db.relationship(
        "Category",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan"
    )
    alerts = db.relationship(
        "Alert",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="Alert.created_at.desc()"
    )
    advisor_snapshots = db.relationship(
        "AdvisorSnapshot",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="AdvisorSnapshot.created_at.desc()"
    )
    savings_goals = db.relationship(
        "SavingsGoal",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="SavingsGoal.created_at.desc()"
    )
    def __repr__(self):
        return f"<User {self.email}>"

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(100), nullable=False, index=True)
    type = db.Column(db.String(20), nullable=False, index=True)  # income / expense
    source = db.Column(db.String(20), nullable=False, default="user", index=True)  # user / dataset
    date = db.Column(db.Date, nullable=False, default=lambda: datetime.utcnow().date())
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    def __repr__(self):
        return f"<Transaction {self.id} - {self.category} - {self.amount} - {self.source}>"

class Budget(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    category = db.Column(db.String(100), nullable=False)
    limit_amount = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    __table_args__ = (
        db.UniqueConstraint("user_id", "category", name="uq_budget_user_category"),
    )
    @property
    def is_valid_limit(self):
        return self.limit_amount is not None and self.limit_amount > 0
    def __repr__(self):
        return f"<Budget {self.user_id} - {self.category} - {self.limit_amount}>"

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    __table_args__ = (
        db.UniqueConstraint("user_id", "name", name="uq_category_user_name"),
    )
    def __repr__(self):
        return f"<Category {self.user_id} - {self.name}>"

class Alert(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=True, index=True)
    alert_type = db.Column(db.String(20), nullable=False, default="warning")  # info / warning / danger
    source = db.Column(db.String(50), nullable=False, default="budget")        # budget / advisor / report / system
    source_id = db.Column(db.Integer, nullable=True)
    alert_key = db.Column(db.String(150), nullable=True, index=True)
    is_read = db.Column(db.Boolean, nullable=False, default=False)
    read_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    def mark_as_read(self):
        self.is_read = True
        self.read_at = datetime.utcnow()
    def mark_as_unread(self):
        self.is_read = False
        self.read_at = None
    def __repr__(self):
        return f"<Alert {self.user_id} - {self.title}>"

class AdvisorSnapshot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    period = db.Column(db.String(20), nullable=False, default="monthly", index=True)
    summary_json = db.Column(db.Text, nullable=True)
    rule_data_json = db.Column(db.Text, nullable=True)
    ai_data_json = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)
    expires_at = db.Column(db.DateTime, nullable=True)
    def set_summary(self, data):
        self.summary_json = json.dumps(data or {})
    def get_summary(self):
        return json.loads(self.summary_json) if self.summary_json else {}
    def set_rule_data(self, data):
        self.rule_data_json = json.dumps(data or {})
    def get_rule_data(self):
        return json.loads(self.rule_data_json) if self.rule_data_json else {}
    def set_ai_data(self, data):
        self.ai_data_json = json.dumps(data or {})
    def get_ai_data(self):
        return json.loads(self.ai_data_json) if self.ai_data_json else {}
    @property
    def is_valid(self):
        return self.expires_at is not None and self.expires_at > datetime.utcnow()
    def __repr__(self):
        return f"<AdvisorSnapshot user={self.user_id} period={self.period}>"

class SavingsGoal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False, index=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    target_amount = db.Column(db.Float, nullable=False)
    current_amount = db.Column(db.Float, nullable=False, default=0.0)
    deadline = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime,
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    contributions = db.relationship(
        "SavingsGoalContribution",
        backref="goal",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="SavingsGoalContribution.created_at.desc()"
    )
    def __repr__(self):
        return f"<SavingsGoal {self.user_id} - {self.name}>"

class SavingsGoalContribution(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    goal_id = db.Column(db.Integer, db.ForeignKey("savings_goal.id"), nullable=False, index=True)
    amount = db.Column(db.Float, nullable=False)
    note = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    def __repr__(self):
        return f"<SavingsGoalContribution goal={self.goal_id} amount={self.amount}>"


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))