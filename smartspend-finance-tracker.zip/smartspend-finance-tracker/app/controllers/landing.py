from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func
from app import db
from app.models import User, Transaction

landing_bp = Blueprint("landing", __name__)

@landing_bp.route("/")
def home():
    return render_template("landing/index.html")

@landing_bp.route("/signup", methods=["GET", "POST"])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for("landing.dashboard"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not name or not email or not password or not confirm_password:
            flash("All fields are required.", "error")
            return render_template("landing/signup.html")

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "error")
            return render_template("landing/signup.html")

        if password != confirm_password:
            flash("Passwords do not match.", "error")
            return render_template("landing/signup.html")

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("An account with this email already exists. Please log in.", "error")
            return render_template("landing/signup.html")

        hashed_password = generate_password_hash(password)

        new_user = User(
            name=name,
            email=email,
            password=hashed_password
        )

        db.session.add(new_user)
        db.session.commit()

        login_user(new_user)
        flash("Account created successfully.", "success")
        return redirect(url_for("landing.dashboard"))

    return render_template("landing/signup.html")

@landing_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("landing.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not email or not password:
            flash("Email and password are required.", "error")
            return render_template("landing/login.html")

        user = User.query.filter_by(email=email).first()

        if not user or not check_password_hash(user.password, password):
            flash("Invalid email or password.", "error")
            return render_template("landing/login.html")

        login_user(user)
        flash("Logged in successfully.", "success")
        return redirect(url_for("landing.dashboard"))

    return render_template("landing/login.html")

@landing_bp.route("/dashboard")
@login_required
def dashboard():
    user_transactions = Transaction.query.filter_by(user_id=current_user.id)

    income_total = (
        db.session.query(func.coalesce(func.sum(Transaction.amount), 0.0))
        .filter_by(user_id=current_user.id, type="income")
        .scalar() or 0.0
    )

    expense_total = (
        db.session.query(func.coalesce(func.sum(Transaction.amount), 0.0))
        .filter_by(user_id=current_user.id, type="expense")
        .scalar() or 0.0
    )

    balance = income_total - expense_total

    recent_transactions = (
        user_transactions
        .order_by(Transaction.date.desc(), Transaction.created_at.desc())
        .limit(5)
        .all()
    )

    top_spending = (
        db.session.query(Transaction.category, func.sum(Transaction.amount).label("total"))
        .filter_by(user_id=current_user.id, type="expense")
        .group_by(Transaction.category)
        .order_by(func.sum(Transaction.amount).desc())
        .first()
    )

    expenses_by_category = (
        db.session.query(Transaction.category, func.sum(Transaction.amount).label("total"))
        .filter_by(user_id=current_user.id, type="expense")
        .group_by(Transaction.category)
        .order_by(func.sum(Transaction.amount).desc())
        .limit(5)
        .all()
    )

    return render_template(
        "landing/dashboard.html",
        username=current_user.name,
        income_total=income_total,
        expense_total=expense_total,
        balance=balance,
        recent_transactions=recent_transactions,
        top_spending=top_spending,
        expenses_by_category=expenses_by_category,
    )

@landing_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "success")
    return redirect(url_for("landing.home"))