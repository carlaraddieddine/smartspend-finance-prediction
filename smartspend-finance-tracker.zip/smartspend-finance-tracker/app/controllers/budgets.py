from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app import db
from app.models import Budget, Transaction, Category, Alert

budgets_bp = Blueprint("budgets", __name__)

DEFAULT_BUDGET_CATEGORIES = [
    "Food",
    "Transportation",
    "Bills",
    "Entertainment",
    "Shopping",
    "Health",
    "Education",
    "Other",
]


def _get_budget_categories():
    expense_categories = {
        tx.category
        for tx in Transaction.query.filter_by(user_id=current_user.id, type="expense").all()
    }
    budget_categories = {
        budget.category
        for budget in Budget.query.filter_by(user_id=current_user.id).all()
    }
    custom_categories = {
        category.name
        for category in Category.query.filter_by(user_id=current_user.id).all()
    }
    return sorted(expense_categories | budget_categories | custom_categories | set(DEFAULT_BUDGET_CATEGORIES))


def _get_current_month_range():
    today = datetime.utcnow().date()
    start_date = today.replace(day=1)
    end_date = today
    return start_date, end_date


def _get_spending_by_category():
    start_date, end_date = _get_current_month_range()

    transactions = (
        Transaction.query
        .filter_by(user_id=current_user.id, type="expense")
        .filter(Transaction.date >= start_date, Transaction.date <= end_date)
        .all()
    )

    spending_map = {}
    for tx in transactions:
        spending_map[tx.category] = spending_map.get(tx.category, 0) + tx.amount

    return spending_map


@budgets_bp.route("/budgets")
@login_required
def budgets():
    budgets = (
        Budget.query
        .filter_by(user_id=current_user.id)
        .order_by(Budget.category.asc())
        .all()
    )

    spending_map = _get_spending_by_category()
    categories = _get_budget_categories()
    budget_rows = []

    for budget in budgets:
        spent_amount = spending_map.get(budget.category, 0)
        remaining_amount = budget.limit_amount - spent_amount
        progress_percent = 0

        if budget.limit_amount > 0:
            progress_percent = (spent_amount / budget.limit_amount) * 100

        if spent_amount > budget.limit_amount:
            status = "exceeded"
        elif progress_percent >= 80:
            status = "warning"
        else:
            status = "safe"

        budget_rows.append({
            "id": budget.id,
            "category": budget.category,
            "limit_amount": budget.limit_amount,
            "spent_amount": spent_amount,
            "remaining_amount": remaining_amount,
            "progress_percent": progress_percent,
            "status": status,
        })

    return render_template(
        "budgets/index.html",
        budgets=budget_rows,
        categories=categories
    )


@budgets_bp.route("/budgets/add", methods=["POST"])
@login_required
def add_budget():
    category = request.form.get("category", "").strip()
    limit_amount_raw = request.form.get("limit_amount", "").strip()

    if not category or not limit_amount_raw:
        flash("Category and budget amount are required.", "error")
        return redirect(url_for("budgets.budgets"))

    try:
        limit_amount = float(limit_amount_raw)
        if limit_amount <= 0:
            raise ValueError
    except ValueError:
        flash("Budget amount must be a valid number greater than zero.", "error")
        return redirect(url_for("budgets.budgets"))

    existing_budget = Budget.query.filter_by(
        user_id=current_user.id,
        category=category
    ).first()

    if existing_budget:
        flash("A budget already exists for this category. You can update it below.", "error")
        return redirect(url_for("budgets.budgets"))

    new_budget = Budget(
        user_id=current_user.id,
        category=category,
        limit_amount=limit_amount
    )

    db.session.add(new_budget)
    db.session.commit()

    flash("Budget added successfully.", "success")
    return redirect(url_for("budgets.budgets"))


@budgets_bp.route("/budgets/update/<int:budget_id>", methods=["POST"])
@login_required
def update_budget(budget_id):
    budget = Budget.query.filter_by(
        id=budget_id,
        user_id=current_user.id
    ).first_or_404()

    limit_amount_raw = request.form.get("limit_amount", "").strip()

    if not limit_amount_raw:
        flash("Budget amount is required.", "error")
        return redirect(url_for("budgets.budgets"))

    try:
        limit_amount = float(limit_amount_raw)
        if limit_amount <= 0:
            raise ValueError
    except ValueError:
        flash("Budget amount must be a valid number greater than zero.", "error")
        return redirect(url_for("budgets.budgets"))

    budget.limit_amount = limit_amount
    db.session.commit()

    flash("Budget updated successfully.", "success")
    return redirect(url_for("budgets.budgets"))


@budgets_bp.route("/budgets/delete/<int:budget_id>", methods=["POST"])
@login_required
def delete_budget(budget_id):
    budget = Budget.query.filter_by(
        id=budget_id,
        user_id=current_user.id
    ).first_or_404()

    Alert.query.filter_by(
        user_id=current_user.id,
        source="budget",
        source_id=budget.id
    ).delete()

    db.session.delete(budget)
    db.session.commit()

    flash("Budget deleted successfully.", "success")
    return redirect(url_for("budgets.budgets"))