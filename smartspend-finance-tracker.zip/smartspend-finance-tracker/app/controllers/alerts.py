from datetime import datetime
from flask import Blueprint, flash, redirect, render_template, url_for
from flask_login import current_user, login_required
from app import db
from app.models import Alert, Budget, Transaction

alerts_bp = Blueprint("alerts", __name__, url_prefix="/alerts")

def get_current_month_spending(user_id, category):
    now = datetime.utcnow()
    month_start = datetime(now.year, now.month, 1).date()
    total = db.session.query(
        db.func.coalesce(db.func.sum(Transaction.amount), 0.0)
    ).filter(
        Transaction.user_id == user_id,
        Transaction.type == "expense",
        Transaction.category == category,
        Transaction.date >= month_start,
    ).scalar()
    return float(total or 0.0)

def find_alert_by_key(user_id, alert_key):
    return Alert.query.filter_by(
        user_id=user_id,
        alert_key=alert_key
    ).first()

def create_alert(
    user_id,
    title,
    message,
    alert_type="warning",
    category=None,
    source="budget",
    source_id=None,
    alert_key=None,
):
    if alert_key:
        existing = find_alert_by_key(user_id, alert_key)
        if existing:
            return None
    alert = Alert(
        user_id=user_id,
        title=title,
        message=message,
        alert_type=alert_type,
        category=category,
        source=source,
        source_id=source_id,
        alert_key=alert_key,
    )
    db.session.add(alert)
    return alert
def delete_alert_by_key(user_id, alert_key):
    alert = Alert.query.filter_by(
        user_id=user_id,
        alert_key=alert_key
    ).first()
    if alert:
        db.session.delete(alert)
        return True
    return False

def generate_budget_alerts_for_user(user_id):
    budgets = Budget.query.filter_by(user_id=user_id).all()
    created_count = 0
    for budget in budgets:
        limit_amount = float(budget.limit_amount or 0)
        near_key = f"budget_near_limit_{budget.id}"
        exceeded_key = f"budget_exceeded_{budget.id}"
        if limit_amount <= 0:
            delete_alert_by_key(user_id, near_key)
            delete_alert_by_key(user_id, exceeded_key)
            continue
        spent = get_current_month_spending(user_id, budget.category)
        usage_ratio = spent / limit_amount        
        if usage_ratio >= 1:
            delete_alert_by_key(user_id, near_key)
            created = create_alert(
                user_id=user_id,
                title="Budget exceeded",
                message=f"You exceeded your {budget.category} budget. Spent ${spent:.2f} out of ${limit_amount:.2f}.",
                alert_type="danger",
                category=budget.category,
                source="budget",
                source_id=budget.id,
                alert_key=exceeded_key,
            )
            if created:
                created_count += 1
        elif usage_ratio >= 0.8:
            delete_alert_by_key(user_id, exceeded_key)
            created = create_alert(
                user_id=user_id,
                title="Near budget limit",
                message=f"You are close to your {budget.category} budget. Spent ${spent:.2f} out of ${limit_amount:.2f}.",
                alert_type="warning",
                category=budget.category,
                source="budget",
                source_id=budget.id,
                alert_key=near_key,
            )
            if created:
                created_count += 1        
        else:
            delete_alert_by_key(user_id, near_key)
            delete_alert_by_key(user_id, exceeded_key)
    db.session.commit()
    return created_count

@alerts_bp.route("/")
@login_required
def index():
    alerts = Alert.query.filter_by(
        user_id=current_user.id
    ).order_by(Alert.created_at.desc()).all()

    unread_count = Alert.query.filter_by(
        user_id=current_user.id,
        is_read=False
    ).count()

    near_limit_count = Alert.query.filter(
        Alert.user_id == current_user.id,
        Alert.title == "Near budget limit"
    ).count()
    return render_template(
        "alerts/index.html",
        alerts=alerts,
        unread_count=unread_count,
        near_limit_count=near_limit_count, 
        total_count=len(alerts)           
    )

@alerts_bp.route("/refresh", methods=["POST"])
@login_required
def refresh_alerts():
    created_count = generate_budget_alerts_for_user(current_user.id)
    if created_count > 0:
        flash(f"{created_count} new alert(s) generated.", "success")
    else:
        flash("No new alerts generated.", "info")
    return redirect(url_for("alerts.index"))

@alerts_bp.route("/<int:alert_id>/read", methods=["POST"])
@login_required
def mark_as_read(alert_id):
    alert = Alert.query.filter_by(
        id=alert_id,
        user_id=current_user.id
    ).first_or_404()
    if not alert.is_read:
        alert.mark_as_read()
        db.session.commit()
        flash("Alert marked as read.", "success")
    return redirect(url_for("alerts.index"))

@alerts_bp.route("/<int:alert_id>/unread", methods=["POST"])
@login_required
def mark_as_unread(alert_id):
    alert = Alert.query.filter_by(
        id=alert_id,
        user_id=current_user.id
    ).first_or_404()
    if alert.is_read:
        alert.mark_as_unread()
        db.session.commit()
        flash("Alert marked as unread.", "success")
    return redirect(url_for("alerts.index"))

@alerts_bp.route("/<int:alert_id>/delete", methods=["POST"])
@login_required
def delete_alert(alert_id):
    alert = Alert.query.filter_by(
        id=alert_id,
        user_id=current_user.id
    ).first_or_404()
    db.session.delete(alert)
    db.session.commit()
    flash("Alert deleted.", "success")
    return redirect(url_for("alerts.index"))