from datetime import datetime

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from app import db
from app.models import SavingsGoal, SavingsGoalContribution
from app.services.savings_goal_service import SavingsGoalService

savings_goals_bp = Blueprint("savings_goals", __name__, url_prefix="/savings-goals")


def _parse_amount(value, field_name):
    try:
        amount = float(value)
        if amount <= 0:
            raise ValueError
        return amount, None
    except (TypeError, ValueError):
        return None, f"{field_name} must be a valid number greater than zero."


def _parse_deadline(value):
    if not value:
        return None, None

    try:
        deadline = datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return None, "Please provide a valid target date."

    if deadline < datetime.utcnow().date():
        return None, "Target date cannot be in the past."

    return deadline, None


@savings_goals_bp.route("/")
@login_required
def index():
    goal_rows = SavingsGoalService.refresh_user_goals(current_user.id)
    summary = SavingsGoalService.get_summary(goal_rows)
    return render_template(
        "savings_goals/index.html",
        goals=goal_rows,
        summary=summary,
        current_date=datetime.utcnow().strftime("%Y-%m-%d"),
    )


@savings_goals_bp.route("/add", methods=["POST"])
@login_required
def add_goal():
    name = request.form.get("name", "").strip()
    description = request.form.get("description", "").strip()
    target_amount_raw = request.form.get("target_amount", "").strip()
    deadline_raw = request.form.get("deadline", "").strip()
    initial_amount_raw = request.form.get("initial_amount", "").strip()

    if not name or not target_amount_raw:
        flash("Goal name and target amount are required.", "error")
        return redirect(url_for("savings_goals.index"))

    target_amount, target_error = _parse_amount(target_amount_raw, "Target amount")
    if target_error:
        flash(target_error, "error")
        return redirect(url_for("savings_goals.index"))

    deadline, deadline_error = _parse_deadline(deadline_raw)
    if deadline_error:
        flash(deadline_error, "error")
        return redirect(url_for("savings_goals.index"))

    goal = SavingsGoal(
        user_id=current_user.id,
        name=name,
        description=description or None,
        target_amount=target_amount,
        deadline=deadline,
    )
    db.session.add(goal)
    db.session.flush()

    if initial_amount_raw:
        initial_amount, initial_error = _parse_amount(initial_amount_raw, "Starting amount")
        if initial_error:
            db.session.rollback()
            flash(initial_error, "error")
            return redirect(url_for("savings_goals.index"))

        contribution = SavingsGoalContribution(
            goal_id=goal.id,
            amount=initial_amount,
            note="Initial savings"
        )
        db.session.add(contribution)

    SavingsGoalService.recalculate_goal(goal)
    db.session.commit()

    flash("Savings goal created successfully.", "success")
    return redirect(url_for("savings_goals.index"))


@savings_goals_bp.route("/<int:goal_id>/contribute", methods=["POST"])
@login_required
def add_contribution(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()

    amount_raw = request.form.get("amount", "").strip()
    note = request.form.get("note", "").strip()

    amount, amount_error = _parse_amount(amount_raw, "Contribution amount")
    if amount_error:
        flash(amount_error, "error")
        return redirect(url_for("savings_goals.index"))

    contribution = SavingsGoalContribution(
        goal_id=goal.id,
        amount=amount,
        note=note or None,
    )
    db.session.add(contribution)
    SavingsGoalService.recalculate_goal(goal)
    db.session.commit()

    flash("Contribution added successfully.", "success")
    return redirect(url_for("savings_goals.index"))


@savings_goals_bp.route("/<int:goal_id>/update", methods=["POST"])
@login_required
def update_goal(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()

    name = request.form.get("name", "").strip()
    description = request.form.get("description", "").strip()
    target_amount_raw = request.form.get("target_amount", "").strip()
    deadline_raw = request.form.get("deadline", "").strip()

    if not name or not target_amount_raw:
        flash("Goal name and target amount are required.", "error")
        return redirect(url_for("savings_goals.index"))

    target_amount, target_error = _parse_amount(target_amount_raw, "Target amount")
    if target_error:
        flash(target_error, "error")
        return redirect(url_for("savings_goals.index"))

    deadline, deadline_error = _parse_deadline(deadline_raw)
    if deadline_error:
        flash(deadline_error, "error")
        return redirect(url_for("savings_goals.index"))

    goal.name = name
    goal.description = description or None
    goal.target_amount = target_amount
    goal.deadline = deadline

    SavingsGoalService.recalculate_goal(goal)
    db.session.commit()

    flash("Savings goal updated successfully.", "success")
    return redirect(url_for("savings_goals.index"))


@savings_goals_bp.route("/<int:goal_id>/delete", methods=["POST"])
@login_required
def delete_goal(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()
    db.session.delete(goal)
    db.session.commit()

    flash("Savings goal deleted successfully.", "success")
    return redirect(url_for("savings_goals.index"))