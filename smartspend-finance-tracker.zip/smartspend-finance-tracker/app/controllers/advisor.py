from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.services.advisor_service import SmartAdvisorService

advisor_bp = Blueprint("advisor", __name__, url_prefix="/advisor")

@advisor_bp.route("/")
@login_required
def index():
    period = request.args.get("period", "monthly").strip().lower()
    if period not in {"weekly", "monthly"}:
        period = "monthly"
    payload = SmartAdvisorService.get_advisor_payload(current_user.id, period=period)
    return render_template(
        "advisor/index.html",
        period=period,
        advisor=payload
    )

@advisor_bp.route("/refresh", methods=["POST"])
@login_required
def refresh():
    period = request.form.get("period", "monthly").strip().lower()
    if period not in {"weekly", "monthly"}:
        period = "monthly"
    SmartAdvisorService.get_advisor_payload(
        current_user.id,
        period=period,
        force_refresh_ai=True
    )
    flash("Smart Advisor refreshed successfully.", "success")
    return redirect(url_for("advisor.index", period=period))