from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime
from sqlalchemy import or_

from app import db
from app.models import Transaction, Category

transactions_bp = Blueprint("transactions", __name__)

DEFAULT_CATEGORIES = [
    "Food", "Transportation", "Bills", "Entertainment", "Shopping",
    "Health", "Education", "Salary", "Freelance", "Other"
]


def _parse_date(date_value: str):
    if not date_value:
        return datetime.utcnow().date()
    try:
        return datetime.strptime(date_value, "%Y-%m-%d").date()
    except ValueError:
        return None

def _get_categories():
    transaction_categories = {
        tx.category for tx in Transaction.query.filter_by(user_id=current_user.id).all()
    }
    custom_categories = {
        category.name for category in Category.query.filter_by(user_id=current_user.id).all()
    }
    return sorted(transaction_categories | custom_categories | set(DEFAULT_CATEGORIES))

@transactions_bp.route("/transactions")
@login_required
def transactions():
    query = Transaction.query.filter_by(user_id=current_user.id)

    search = request.args.get("search", "").strip()
    type_filter = request.args.get("type", "all").strip().lower()
    category_filter = request.args.get("category", "all").strip()
    from_date_raw = request.args.get("from_date", "").strip()
    to_date_raw = request.args.get("to_date", "").strip()

    if search:
        query = query.filter(
            or_(
                Transaction.category.ilike(f"%{search}%"),
                Transaction.type.ilike(f"%{search}%")
            )
        )

    if type_filter and type_filter != "all":
        query = query.filter_by(type=type_filter)

    if category_filter and category_filter != "all":
        query = query.filter_by(category=category_filter)

    from_date = _parse_date(from_date_raw) if from_date_raw else None
    to_date = _parse_date(to_date_raw) if to_date_raw else None

    if from_date_raw and from_date is None:
        flash("Invalid From date.", "error")
        return redirect(url_for("transactions.transactions"))

    if to_date_raw and to_date is None:
        flash("Invalid To date.", "error")
        return redirect(url_for("transactions.transactions"))

    if from_date:
        query = query.filter(Transaction.date >= from_date)

    if to_date:
        query = query.filter(Transaction.date <= to_date)

    transactions = query.order_by(Transaction.date.desc(), Transaction.created_at.desc()).all()
    categories = _get_categories()

    return render_template(
        "transactions/index.html",
        transactions=transactions,
        categories=categories,
        filters={
            "search": search,
            "type": type_filter or "all",
            "category": category_filter or "all",
            "from_date": from_date_raw,
            "to_date": to_date_raw,
        }
    )


@transactions_bp.route("/transactions/add", methods=["GET"])
@login_required
def add_transaction_page():
    categories = _get_categories()
    return render_template(
        "transactions/add.html",
        categories=categories,
        current_date=datetime.utcnow().strftime("%Y-%m-%d")
    )


@transactions_bp.route("/transactions/add", methods=["POST"])
@login_required
def add_transaction():
    amount_raw = request.form.get("amount", "").strip()
    category = request.form.get("category", "").strip()
    type_ = request.form.get("type", "").strip().lower()
    date_raw = request.form.get("date", "").strip()

    if not amount_raw or not category or not type_:
        flash("Amount, category, and type are required.", "error")
        return redirect(url_for("transactions.add_transaction_page"))

    try:
        amount = float(amount_raw)
        if amount <= 0:
            raise ValueError
    except ValueError:
        flash("Amount must be a valid number greater than zero.", "error")
        return redirect(url_for("transactions.add_transaction_page"))

    if type_ not in {"income", "expense"}:
        flash("Invalid transaction type.", "error")
        return redirect(url_for("transactions.add_transaction_page"))

    parsed_date = _parse_date(date_raw)
    if parsed_date is None:
        flash("Please provide a valid date.", "error")
        return redirect(url_for("transactions.add_transaction_page"))

    new_tx = Transaction(
        user_id=current_user.id,
        amount=amount,
        category=category,
        type=type_,
        source="user",
        date=parsed_date,
    )

    db.session.add(new_tx)
    db.session.commit()

    flash("Transaction added successfully.", "success")
    return redirect(url_for("transactions.transactions"))


@transactions_bp.route("/transactions/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit_transaction(id):
    tx = Transaction.query.get_or_404(id)

    if tx.user_id != current_user.id:
        flash("Unauthorized action.", "error")
        return redirect(url_for("transactions.transactions"))

    categories = _get_categories()

    if request.method == "POST":
        amount_raw = request.form.get("amount", "").strip()
        category = request.form.get("category", "").strip()
        type_ = request.form.get("type", "").strip().lower()
        date_raw = request.form.get("date", "").strip()

        if not amount_raw or not category or not type_:
            flash("Amount, category, and type are required.", "error")
            return render_template("transactions/edit.html", tx=tx, categories=categories)

        try:
            amount = float(amount_raw)
            if amount <= 0:
                raise ValueError
        except ValueError:
            flash("Amount must be a valid number greater than zero.", "error")
            return render_template("transactions/edit.html", tx=tx, categories=categories)

        if type_ not in {"income", "expense"}:
            flash("Invalid transaction type.", "error")
            return render_template("transactions/edit.html", tx=tx, categories=categories)

        parsed_date = _parse_date(date_raw)
        if parsed_date is None:
            flash("Please provide a valid date.", "error")
            return render_template("transactions/edit.html", tx=tx, categories=categories)

        tx.amount = amount
        tx.category = category
        tx.type = type_
        tx.date = parsed_date

        db.session.commit()
        flash("Transaction updated successfully.", "success")
        return redirect(url_for("transactions.transactions"))

    return render_template("transactions/edit.html", tx=tx, categories=categories)


@transactions_bp.route("/transactions/delete/<int:id>", methods=["POST"])
@login_required
def delete_transaction(id):
    tx = Transaction.query.get_or_404(id)

    if tx.user_id != current_user.id:
        flash("Unauthorized action.", "error")
        return redirect(url_for("transactions.transactions"))

    db.session.delete(tx)
    db.session.commit()

    flash("Transaction deleted.", "success")
    return redirect(url_for("transactions.transactions"))