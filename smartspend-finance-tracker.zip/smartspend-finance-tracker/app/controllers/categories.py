from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from sqlalchemy import func

from app import db
from app.models import Transaction, Category, Budget

categories_bp = Blueprint("categories", __name__)

DEFAULT_EXPENSE_CATEGORIES = [
    "Food",
    "Transportation",
    "Bills",
    "Entertainment",
    "Shopping",
    "Health",
    "Education",
    "Other",
]

def _get_all_categories():
    custom_categories = {
        category.name
        for category in Category.query.filter_by(user_id=current_user.id).all()
    }
    transaction_categories = {
        tx.category
        for tx in Transaction.query.filter_by(user_id=current_user.id, type="expense").all()
    }
    return sorted(set(DEFAULT_EXPENSE_CATEGORIES) | custom_categories | transaction_categories)

@categories_bp.route("/categories")
@login_required
def categories():
    totals = (
        db.session.query(
            Transaction.category,
            func.coalesce(func.sum(Transaction.amount), 0.0).label("total")
        )
        .filter_by(user_id=current_user.id, type="expense")
        .group_by(Transaction.category)
        .order_by(func.sum(Transaction.amount).desc())
        .all()
    )
    totals_map = {category: float(total) for category, total in totals}
    all_categories = _get_all_categories()
    custom_categories = Category.query.filter_by(user_id=current_user.id).all()
    custom_category_map = {category.name: category for category in custom_categories}
    category_rows = []
    for category_name in all_categories:
        custom_category = custom_category_map.get(category_name)
        category_rows.append({
        "id": custom_category.id if custom_category else None,
        "name": category_name,
        "total": totals_map.get(category_name, 0.0),
        "is_custom": custom_category is not None
    })
    chart_labels = []
    chart_values = []
    for category_name, total in totals:
        if total > 0:
            chart_labels.append(category_name)
            chart_values.append(float(total))
    return render_template(
        "categories/index.html",
        categories=category_rows,
        chart_labels=chart_labels,
        chart_values=chart_values
    )

@categories_bp.route("/categories/add", methods=["POST"])
@login_required
def add_category():
    name = request.form.get("name", "").strip()
    if not name:
        flash("Category name is required.", "error")
        return redirect(url_for("categories.categories"))
    normalized_name = name.title()
    existing_default = normalized_name in DEFAULT_EXPENSE_CATEGORIES
    existing_custom = Category.query.filter_by(
        user_id=current_user.id,
        name=normalized_name
    ).first()
    if existing_default or existing_custom:
        flash("This category already exists.", "error")
        return redirect(url_for("categories.categories"))
    new_category = Category(
        user_id=current_user.id,
        name=normalized_name
    )
    db.session.add(new_category)
    db.session.commit()
    flash("Category added successfully.", "success")
    return redirect(url_for("categories.categories"))

@categories_bp.route("/categories/delete/<int:id>", methods=["POST"])
@login_required
def delete_category(id):
    category = Category.query.get_or_404(id)
    if category.user_id != current_user.id:
        flash("Unauthorized action.", "error")
        return redirect(url_for("categories.categories"))
    transaction_exists = Transaction.query.filter_by(
        user_id=current_user.id,
        category=category.name
    ).first()
    if transaction_exists:
        flash("Cannot delete this category because it is used in transactions.", "error")
        return redirect(url_for("categories.categories"))
    budget_exists = Budget.query.filter_by(
        user_id=current_user.id,
        category=category.name
    ).first()
    if budget_exists:
        flash("Cannot delete this category because it is used in budgets.", "error")
        return redirect(url_for("categories.categories"))
    db.session.delete(category)
    db.session.commit()
    flash("Category deleted successfully.", "success")
    return redirect(url_for("categories.categories"))