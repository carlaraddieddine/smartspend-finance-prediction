from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required
from werkzeug.security import check_password_hash, generate_password_hash

from app import db
from app.models import User

settings_bp = Blueprint("settings", __name__, url_prefix="/settings")

AVAILABLE_CURRENCIES = ["USD", "EUR", "GBP", "EGP", "LBP"]


@settings_bp.route("/", methods=["GET", "POST"])
@login_required
def index():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        preferred_currency = request.form.get("preferred_currency", "USD").strip().upper()
        notifications_enabled = request.form.get("notifications_enabled") == "on"

        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not name or not email:
            flash("Name and email are required.", "error")
            return redirect(url_for("settings.index"))

        if preferred_currency not in AVAILABLE_CURRENCIES:
            flash("Please choose a valid currency.", "error")
            return redirect(url_for("settings.index"))

        existing_user = User.query.filter(
            User.email == email,
            User.id != current_user.id
        ).first()

        if existing_user:
            flash("That email is already being used by another account.", "error")
            return redirect(url_for("settings.index"))

        current_user.name = name
        current_user.email = email
        current_user.preferred_currency = preferred_currency
        current_user.notifications_enabled = notifications_enabled

        password_fields_filled = current_password or new_password or confirm_password
        if password_fields_filled:
            if not current_password or not new_password or not confirm_password:
                flash("To change your password, fill in all password fields.", "error")
                return redirect(url_for("settings.index"))

            if not check_password_hash(current_user.password, current_password):
                flash("Current password is incorrect.", "error")
                return redirect(url_for("settings.index"))

            if len(new_password) < 6:
                flash("New password must be at least 6 characters.", "error")
                return redirect(url_for("settings.index"))

            if new_password != confirm_password:
                flash("New password and confirmation do not match.", "error")
                return redirect(url_for("settings.index"))

            current_user.password = generate_password_hash(new_password)

        db.session.commit()
        flash("Settings updated successfully.", "success")
        return redirect(url_for("settings.index"))

    return render_template(
        "settings/index.html",
        currencies=AVAILABLE_CURRENCIES
    )