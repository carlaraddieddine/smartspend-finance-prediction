from flask import Blueprint, render_template, request
from flask_login import login_required, current_user
from datetime import datetime, timedelta

from app.models import Transaction

reports_bp = Blueprint("reports", __name__)


def _get_period_dates(period: str):
    today = datetime.utcnow().date()

    if period == "weekly":
        start_date = today - timedelta(days=6)
        end_date = today
    else:
        start_date = today.replace(day=1)
        end_date = today

    return start_date, end_date


@reports_bp.route("/reports")
@login_required
def reports():
    period = request.args.get("period", "monthly").strip().lower()
    if period not in {"weekly", "monthly"}:
        period = "monthly"

    start_date, end_date = _get_period_dates(period)

    transactions = (
        Transaction.query
        .filter_by(user_id=current_user.id)
        .filter(Transaction.date >= start_date, Transaction.date <= end_date)
        .order_by(Transaction.date.asc())
        .all()
    )

    income_total = sum(tx.amount for tx in transactions if tx.type == "income")
    expense_total = sum(tx.amount for tx in transactions if tx.type == "expense")
    balance = income_total - expense_total

    # Income vs expense chart data
    if period == "weekly":
        labels = []
        income_data = []
        expense_data = []

        for i in range(7):
            current_day = start_date + timedelta(days=i)
            labels.append(current_day.strftime("%a"))

            day_income = sum(
                tx.amount for tx in transactions
                if tx.type == "income" and tx.date == current_day
            )
            day_expense = sum(
                tx.amount for tx in transactions
                if tx.type == "expense" and tx.date == current_day
            )

            income_data.append(day_income)
            expense_data.append(day_expense)

    else:
        labels = []
        income_data = []
        expense_data = []

        today = datetime.utcnow().date()
        days_in_month = today.day

        for i in range(1, days_in_month + 1):
            current_day = start_date.replace(day=i)
            labels.append(str(i))

            day_income = sum(
                tx.amount for tx in transactions
                if tx.type == "income" and tx.date == current_day
            )
            day_expense = sum(
                tx.amount for tx in transactions
                if tx.type == "expense" and tx.date == current_day
            )

            income_data.append(day_income)
            expense_data.append(day_expense)

    # Category breakdown chart data
    category_totals = {}
    for tx in transactions:
        if tx.type == "expense":
            category_totals[tx.category] = category_totals.get(tx.category, 0) + tx.amount

    category_labels = list(category_totals.keys())
    category_values = list(category_totals.values())

    return render_template(
        "reports/index.html",
        period=period,
        income_total=income_total,
        expense_total=expense_total,
        balance=balance,
        chart_labels=labels,
        income_data=income_data,
        expense_data=expense_data,
        category_labels=category_labels,
        category_values=category_values,
    )