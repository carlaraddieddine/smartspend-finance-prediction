from dotenv import load_dotenv
load_dotenv()
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "landing.login"

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "dev-secret-key"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    db.init_app(app)
    login_manager.init_app(app)

    from app.models import (
        User, Transaction, Budget, Category, Alert, AdvisorSnapshot, SavingsGoal, SavingsGoalContribution)
    from app.controllers.landing import landing_bp
    from app.controllers.transactions import transactions_bp
    from app.controllers.reports import reports_bp
    from app.controllers.budgets import budgets_bp
    from app.controllers.categories import categories_bp
    from app.controllers.alerts import alerts_bp
    from app.controllers.advisor import advisor_bp
    from app.controllers.savings_goals import savings_goals_bp
    from app.controllers.settings import settings_bp

    app.register_blueprint(landing_bp)
    app.register_blueprint(transactions_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(budgets_bp)
    app.register_blueprint(categories_bp)
    app.register_blueprint(alerts_bp)
    app.register_blueprint(advisor_bp)
    app.register_blueprint(savings_goals_bp)
    app.register_blueprint(settings_bp)

    with app.app_context():
        db.create_all()

    return app